# Thai Sentiment API

FastAPI backend for Thai social media sentiment analysis.

## Endpoint
POST /predict

### Request
```json
{
  "text": "เลือกตั้งกี่รอบก็เหมือนเดิม เบียว 🙄"
}
